//ACCESS INPUT FIELD
var add = document.getElementById('add');
//ACCCESS BUTTON FOR ADD VALUES
var btn = document.querySelector('.btn').onclick = function() {
	//CREATE BLANK ARREY 
    var arr = [];
	//ADD INPUT VALUES IN BLANK ARREY BY PUSH METHOD
    arr.push(add.value);
    //console.log(arr);
    //add.value = "";
	
	//CREATE LOOP FOR ADD DATA IN DATA CLASS IN  DIV
    for (var i in arr) {
		//ACCESS DATA CLASS 
        document.querySelector('.data').innerHTML += `
            <div class="list01 wow animate bounceInUp">
				<p class="para"><span class="list">${arr[i]}</span></p>
			    <span class="del"><i class="far fa-trash-alt"></i></span>
                <span class="btn  ok"><i class="far fa-bookmark"></i></span>
			<div>
		 `;
    }
	
	//CREATE DELETE BUTTON 
    var del = document.getElementsByClassName('del');
	//CREATE LOOP FOR DELETE BUTTON
    for (var i = 0; i < del.length; i++) {
		//ADD ONCLICK FUNCTION FOR PER DELETE BUTTON
        del[i].addEventListener("click", function() {
			//DELETE SPECIFIC BUTTON FOR DELETE TASK 
            this.parentElement.style.display = 'none';
        })
    }
	
	//CREATE EDITER
    var para = document.getElementsByClassName('para');
	//ACCCESS  ALL TASK BLOCKS 
    for (var i in para) {
		//GIVE ONLCICK EVENT IN PER BLOCK CONTENT
        para[i].addEventListener('click', function() {
			//GIVE CONDITION FOR CLICKED OR NOTCLICKED\
			//CLICKED TRUE
            if (para[i].clicked = true) {
                this.contentEditable = true;
                this.style.border = "none";
            } else {//CLICKED FALSE
                this.contentEditable = false;
            }
        });
    }
}

//ADD DATE MONTHS AND DAYS
dat = ()=>{
	var date = document.getElementById('date');
	var d = new Date();
	date.innerHTML+=d;
	
}
dat()